package com.rasco.SpendingReporter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpendingReporterApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpendingReporterApplication.class, args);
	}

}
